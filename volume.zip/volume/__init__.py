import os


import audio_controller
AudioController = audio_controller.AudioController

del audio_controller, os


